addpath(genpath("scripts"));
application = 'gui.mlapp';
run(application);