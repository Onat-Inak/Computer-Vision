function all_clear()
%This function will clear the work space and plots
%   all data in work space and also the plots should be deleted/closed
%   after the program is finished
    clear all
    close all hidden
end

