% just run this main.m to start our program
path(path,'interface')
CV2021Challenge_TabManager