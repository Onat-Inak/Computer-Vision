# GeoCompare

Computer Vision Challenge 2021

Gruppenmitglieder: Johannes Kunz, Markus Kaschke, Hinrich Sackmann, Robert Ruidisch, Paul Zech

## Requirements
Matlab Version 2021a or newer with Computer Vision & Image Processing Toolboxes installed

## Purpose
GeoCOMPARE is a software tool for detecting and visualizing large-scale changes in the environment. 
The user inputs sattelite images of the same location, which are taken at different points in time. 
As the images may have different rotation, scaling of perspective, the software first aligns all images.
Once the images are overlayed, the changes in the environment are visualized. 
For easy usage, the tool provides a graphical user interface.
Overall, the software is structured into three main components, an image registration algorithm, multiple image comparison algorithms, and graphical user interface. 
The main process is controlled by the GUI that calls functions for the registration and the comparison, respectively.

## How to start the software
Please open the cv_gui_main.m file in Matlab and press on "Run" then the GUI should load.
If you can't start the GUI or want to see some code than you can execute the software using the provided Livescript geoCompare.mlx

If the scaling of the GUI is not correct, i.e. parts of the window are cropped away, please ajust the dispaly scaling of your OS. On Windows, set it to 100% and on MacOS go to Monitor > Resolution > Scaled >  More Area. 