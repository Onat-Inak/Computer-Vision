function success = guiDifference(invObj)
% Connector: GUI <--> Check Differences

    % Chosen reference image
    aligned_images = invObj.alignedImagesRGB;
    
    nfiles = length(aligned_images);
    refImageComp = invObj.refImageComp;
    findNRefComp = @(x) strcmp(x, refImageComp);
    nRefComp = cellfun(findNRefComp, invObj.imageCellArray);

    %% Calculate Difference
    
    colorBlind = invObj.colorBlind;
    
    aligned_images = invObj.alignedImages;
    
    % Selected reference Image
    indexNRef = find(nRefComp);
    if indexNRef > length(aligned_images)
        nRefComp = 1;
        warning("The reference image for comparison has no match!");
        warning("Reference image is: " + invObj.imageCellArray{1});
    end
    A = aligned_images{nRefComp};
    black_a = A<=1;
    invObj.fusedImage = cell(1,nfiles);
    for i=1:nfiles

        B = aligned_images{i}; 
        black_b = B<=1;

        if ~invObj.colorBlind
            img = imfuse(A, B,...
                                   'falsecolor', 'ColorChannels', 'red-cyan');
        else
            img = imfuse(A, B,...
                                   'falsecolor', 'ColorChannels', 'green-magenta');
        end
        
        % Crop the black corner
        img(black_a) = 0;
        img(black_b) = 0;

        invObj.fusedImage{i} = img;
    end
    colorBlind = invObj.colorBlind;
    
	invObj.fusedImage = difference_calculation(aligned_images,nRefComp, colorBlind);
    invObj.imgDifffPercent = calc_img_change(aligned_images, nRefComp);
    
    invObj.success = true;
    success = true;
end

