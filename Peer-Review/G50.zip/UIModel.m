classdef UIModel < handle
    %UIMODEL Summary of this class goes here
    %   Detailed explanation goes here
    properties (Access = protected, Constant = true)
        DefaultDirs = ["./Datasets/Brazilian Rainforest",...
                       "./Datasets/Columbia Glacier",...
                       "./Datasets/Dubai",...
                       "./Datasets/Frauenkirche",...
                       "./Datasets/Kuwait",...
                       "./Datasets/Wiesn"];
        fileEnding = ["*.jpg", "*.png"];
    end
    properties (SetObservable)
        % Cell array that contains structs returned by dir(...)
        cellArrayDirs
        % Cell array that contains strings that represent the dir path
        AddedDirs
        % Array that contains Classification objects
        cellArrayPastInvestigations
        % This property stores the progress of alignment
        %progress
    end
    
    properties
        matObj
        View
        
        selectedTrainDir
        selectedTestDir
        selectedFile
        selectedAlgorithm
        
        lastInvestigation
        
        selectedDir
        selectedRefImage
        selectedFeature
        
        selectedRefImageComp
        imageToCompare
        
        minProgress
        maxProgress
        colorBlind
        
        currentFuseImageIndex
    end
    
%==========================================================================    
    methods
%==========================================================================
        function self = UIModel(view)
            % If storage.mat does not exist this file is created by
            % matfile(...). The matfile functions opens an IO channel
            self.matObj = matfile('storage.mat', "Writable",true);
            self.View = view;
            
            
            self.minProgress = 0;
            self.maxProgress = 0;
            self.currentFuseImageIndex = 0;
            % Only the last 3 investigations are stored in the storage.mat
            % file
            %self.cellArrayPastInvestigations = cell(1,2);
            
            self.selectedDir = "";
            self.selectedRefImage = "";
            addlistener(self, 'cellArrayDirs', 'PostSet', @(~,~) self.updateMatObj);
            addlistener(self, 'AddedDirs', 'PostSet', @(~,~) self.updateMatObj);
            
        end
%==========================================================================
        function success = startAlignment(self)
        % Button to start the Alignment of the images
            invObj = Investigation();
            success = false;
            self.lastInvestigation = '';
            imageCellArray = self.retrieveFilesFromDir(self.selectedDir);
            
            files = cell(1,length(imageCellArray));
            for i = 1:length(imageCellArray)
                tmp = strsplit(imageCellArray{i}, filesep);
                tmp2 = tmp(end);
                tmp3 = strsplit(tmp2, ".");
                files{i} = tmp3(1);
            end
            invObj.fileNames = files;
            rootDir = strsplit(imageCellArray{1}, filesep);
            % The directory is already part of the images
            rootDir = join(rootDir(1:end-2), filesep);
            
            invObj.imageCellArray = imageCellArray;
            invObj.refImage = rootDir + ""+filesep+self.selectedRefImage;
            invObj.refImageComp = rootDir + ""+filesep+self.selectedRefImageComp;
            invObj.rootDir = rootDir;
            invObj.date =  datetime;
            
            self.minProgress = 1;
            self.maxProgress = length(imageCellArray);
            
            try
                success = guiAlignment(invObj, self);
                self.lastInvestigation = invObj;
            catch exception
                getReport(exception)
            end
        end
    %==========================================================================
        function playVideo(self)
            invObj = self.lastInvestigation;
            alignedImagesRGB = invObj.alignedImagesRGB;
            refImageComp = invObj.refImageComp;
            colorBlind = self.colorBlind;
            play = true;
            
            create_movie_seq(alignedImagesRGB, refImageComp, colorBlind, play, invObj);
            
            
        end
%==========================================================================
        function startDifferences(self)
        % Button to investigate the differences of the images   
            invObj = self.lastInvestigation;
            invObj.refImageComp = invObj.rootDir + ""+filesep+self.selectedRefImageComp;
            
            invObj.colorBlind = self.colorBlind;
            
            try
                success = guiDifference(invObj);
            catch exception
                getReport(exception)
            end       
        end
%==========================================================================
        function updateProgress(self, x)
            if x >= self.minProgress && x <= self.maxProgress
                self.View.updateProgress(x)
            end
        end
%==========================================================================
        function [success, msg] = addDirToStorage(self, selectedDir)
            success = false;
            msg = sprintf("Directory could not be added.\nEither it does not contain any JPG or PNG files or it's alreay added!");
            if ~self.dirAlreadyAdded(selectedDir)
                self.AddedDirs{end+1} = selectedDir;
                dirStruct = dir(selectedDir+""+filesep+"*.jpg");
                filesPNG = dir(selectedDir+""+filesep+"*.png");
                
                if length(filesPNG) >= 1 && length(dirStruct) >=1
                    dirStruct(end+1) = filesPNG;
                elseif isempty(dirStruct) && length(filesPNG) >= 1
                    dirStruct = filesPNG;
                end
                
                if length(dirStruct) >= 1
                    self.cellArrayDirs{end+1} = dirStruct;
                    success = true;
                    msg = "";
                end
            end
           
        end

%==========================================================================
        function removeDirFromStorage(self, dirToRemove)

            for i = 1:length(self.cellArrayDirs)
                folder = self.cellArrayDirs{i}.folder;
                if contains(folder, dirToRemove)
                    self.cellArrayDirs(i) = [];
                    break;
                end
            end
          
            for i = 1:length(self.AddedDirs)
                if contains(self.AddedDirs{i}, dirToRemove)
                    self.AddedDirs{i} = [];
                    break;
                end
            end
            
            if contains(self.selectedDir, dirToRemove)
                self.selectedDir = "";
                self.selectedRefImage = "";
            end
            self.updateMatObj();
        end
%==========================================================================
        function alreadyAdded = dirAlreadyAdded(self, dirName)
            alreadyAdded = false;
            for i = 1:length(self.cellArrayDirs)
                folder = self.cellArrayDirs{i}.folder;
                if contains(folder, dirName)
                    alreadyAdded = true;
                    return
                end
            end
            
            for i = 1:length(self.AddedDirs)
                folder = self.AddedDirs{i};
                if contains(folder, dirName)
                    alreadyAdded = true;
                    return
                end
            end
        end
%==========================================================================  
        function updateMatObj(self)
             self.matObj.AddedDirs = self.AddedDirs;
             self.matObj.cellArrayDirs = self.cellArrayDirs;
             %self.matObj.cellArrayPastInvestigations = self.cellArrayPastInvestigations;
        end
%==========================================================================
        function [cellArrayFiles, fileNames] = retrieveFilesFromDir(self, dirTxt)
            indexDir = -1;
            cellArrayFiles = {};
            fileNames = {};
            for i = 1:length(self.cellArrayDirs)
                structDir = self.cellArrayDirs{i};
                folder = {structDir.folder};
                if contains(folder{1}, dirTxt)
                    indexDir = i;
                    break;
                end
            end
            if indexDir >= 1
                structDir = self.cellArrayDirs{indexDir};
                folder = {structDir.folder};
                
                updatedDir = dir(folder{1}+""+filesep+"*.jpg");
                filesPNG = dir(folder{1}+""+filesep+"*.png");
   
                if length(filesPNG) >= 1 && length(updatedDir) >=1
                    updatedDir(end+1) = filesPNG;
                elseif isempty(updatedDir) && length(filesPNG) >= 1
                    updatedDir = filesPNG;
                end
                
                fCount = length(updatedDir);
                cellArrayFiles = cell(fCount,1);
                fileNames = cell(fCount, 1);
                fNames = {updatedDir.name};
                for i = 1:fCount
                    cellArrayFiles{i} = folder{i} + ""+ filesep +  fNames{i};
                    fileNames{i} = fNames{i};
                end
            end
            
            
        end
%==========================================================================
        function checkIfDirExists(self)
            if length(self.cellArrayDirs) >= 1
                for i = length(self.cellArrayDirs):-1:1
                    folder = self.cellArrayDirs{i}.folder;
                    if ~exist(folder, "dir")

                        self.cellArrayDirs(i) = [];

                    end
                end
            end
            
            if length(self.AddedDirs) >= 1
                for i = length(self.AddedDirs):-1:1
                    if ~exist(self.AddedDirs{i}, "dir")
                        self.AddedDirs(i) = [];
                    end
                end
            end
            self.updateMatObj();
        end
%==========================================================================
        function updateFileList(self)
            for i = 1:length(self.cellArrayDirs)
                folder = self.cellArrayDirs{i}.folder;
                
                updatedDir = dir(folder+""+filesep+"*.jpg");
                filesPNG = dir(folder+""+filesep+"*.png");
                
                if length(filesPNG) >= 1 && length(updatedDir) >=1
                    updatedDir(end+1) = filesPNG;
                elseif isempty(updatedDir) && length(filesPNG) >= 1
                    updatedDir = filesPNG;
                end
                
                self.cellArrayDirs{i} = updatedDir;
            end
            self.updateMatObj();
        end
%==========================================================================        
        function updateStorage(self)
            self.matObj.DefaultDirs = self.DefaultDirs;
            self.cellArrayDirs = self.initilizeStorage();
            self.matObj.cellArrayDirs = self.cellArrayDirs;
            self.matObj.AddedDirs = self.AddedDirs;
            %self.matObj.cellArrayPastInvestigations = self.cellArrayPastInvestigations;
            
            if length(self.AddedDirs) < 1
                self.AddedDirs = {};
            end

        end
%==========================================================================        
        function set.matObj(self, matObj)
            self.matObj = matObj;
            if ~exist(self.matObj.Properties.Source, 'file')
               self.updateStorage();
            else
                self.cellArrayDirs = self.matObj.cellArrayDirs;
                self.AddedDirs = self.matObj.AddedDirs;
                
                %self.cellArrayPastInvestigations = ...
                %    self.matObj.cellArrayPastInvestigations;
                
                
            end
            
            self.checkIfDirExists();
            self.updateFileList();
            
        end
%==========================================================================  
    end
%==========================================================================    
    methods (Access = private)
%==========================================================================
        function cellsDefaultDirs = initilizeStorage(self)
            
           
            for i = 1:length(self.DefaultDirs)
                
                dirName = self.DefaultDirs(i);
                if exist(dirName, "dir")
                    files = dir(dirName+""+filesep+"*.jpg");
                    filesPNG = dir(dirName+""+filesep+"*.png");
                    
                    if length(filesPNG) >= 1 && length(files) >=1
                        files(end+1) = filesPNG;
                    elseif isempty(files) && length(filesPNG) >= 1
                        files = filesPNG;
                    end
                    cellsDefaultDirs{i} = files;

                end
            end
            
        end
%==========================================================================

    end
%==========================================================================
end

