function [mov] = create_movie_seq(alignedImagesRGB, refImageComp, colorBlind, play, invObj)
% Creates movie sequence for fast/relaxed comparison

nfiles = length(alignedImagesRGB);
nRefComp = -1;

findNRefComp = @(x) strcmp(x, refImageComp);

nRefComp = find(cellfun(findNRefComp, invObj.imageCellArray));
indexNRef = find(nRefComp);
if indexNRef > nfiles
    nRefComp = 1;
    warning("The reference image for comparison has no match!");
    warning("Reference image is: " + invObj.imageCellArray{1});
end

[sz1, sz2, sz3] = size(alignedImagesRGB{1}); 
im_diff_stacked = NaN(sz1, sz2, sz3, length(alignedImagesRGB)-1); 

% Reference image with cropped black boarder
A = alignedImagesRGB{nRefComp};
black_a = A<=1;

for i = 1:nfiles
    A = alignedImagesRGB{nRefComp};

    B = alignedImagesRGB{i};
    % Overlay images to display changes
    if ~colorBlind
        C = imfuse(A,B, 'falsecolor', 'ColorChannels', 'red-cyan'); 
    else 
       C = imfuse(A,B, 'falsecolor', 'ColorChannels', 'green-magenta');
    end
    % Crop black border around image
    black_b = B<=1;
    C(black_a) = 0;
    C(black_b) = 0;
    im_diff_stacked(:,:,:,i) = im2double(C); 
end

% Create Movie
mov = immovie(im_diff_stacked);
if play
    fps = 1;
    implay(mov,fps)
end
end