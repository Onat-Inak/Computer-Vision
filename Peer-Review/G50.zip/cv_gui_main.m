classdef cv_gui_main < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                       matlab.ui.Figure
        HTML2                          matlab.ui.control.HTML
        InvestigatePanel               matlab.ui.container.Panel
        PlayVideoButton                matlab.ui.control.Button
        ColorblindfusionCheckBox       matlab.ui.control.CheckBox
        NextButton                     matlab.ui.control.Button
        PreviousButton                 matlab.ui.control.Button
        ReferenceImageDropDown_2       matlab.ui.control.DropDown
        ReferenceImageDropDown_2Label  matlab.ui.control.Label
        InvestigateButton              matlab.ui.control.Button
        SelectedImagePanel             matlab.ui.container.Panel
        HeightPixelEditField           matlab.ui.control.NumericEditField
        HeightPixelEditFieldLabel      matlab.ui.control.Label
        WidthPixelEditField            matlab.ui.control.NumericEditField
        WidthPixelLabel                matlab.ui.control.Label
        FileNameEditField              matlab.ui.control.EditField
        FileNameEditFieldLabel         matlab.ui.control.Label
        DataSelectionPanel             matlab.ui.container.Panel
        ProgressEditField              matlab.ui.control.EditField
        AlignImagesButton              matlab.ui.control.Button
        DirectoryDropDown              matlab.ui.control.DropDown
        DirectoryDropDownLabel         matlab.ui.control.Label
        ReferenceImageDropDown         matlab.ui.control.DropDown
        ReferenceImageDropDownLabel    matlab.ui.control.Label
        RemoveButton                   matlab.ui.control.Button
        AddButton                      matlab.ui.control.Button
        Tree                           matlab.ui.container.Tree
        UIAxes2                        matlab.ui.control.UIAxes
        UIAxes                         matlab.ui.control.UIAxes
    end

    properties (Access = private, Constant = true)
        startUpScreenPath = "./start-up-screen/start-up-screen.png";
    end
    
    properties (Access = private)
        Model;
        colorMapProgress;
    end
%==========================================================================
    methods (Access = private)
%==========================================================================
    function initColorMapProgress(app)
        cols = 100;
        left_color = [1 0 0]; % white
        right_color = [0 1 0]; % color according to the attached image
        cmap = interp1([0, 1], [left_color; right_color], linspace(0, 1, cols));
        
        app.colorMapProgress = cmap;
    end
%==========================================================================
    function updateViewFromModel(app)
            delete(app.Tree.Children)
            
            cellArrayDirs = app.Model.cellArrayDirs;
            
            folders = cell(1,length(cellArrayDirs));
            foldersComplete = cell(1,length(cellArrayDirs));
            
            for i = 1:length(cellArrayDirs)
                folder = {cellArrayDirs{i}.folder};
                folderSplit = strsplit(folder{1},filesep);
                
                foldersComplete{i} = folder(1);
                folders{i} = char(folderSplit(end));
            end
            
            
            for i = 1:length(cellArrayDirs)
                
                
                fNames = {cellArrayDirs{i}.name};
                
                parent = uitreenode(app.Tree, "Text", folders{i},...
                                    "NodeData", foldersComplete{i});
                
                for j = 1:length(fNames)
                    uitreenode(parent,"Text", fNames{j},...
                               "NodeData", fNames{j});
                end
            end

            app.DirectoryDropDown.Items = folders;
            app.DirectoryDropDownValueChanged();
          
            
    end
%==========================================================================
    function updatePercentagePlot(app)
        app.UIAxes2.Visible = true;
        invObj = app.Model.lastInvestigation;
        nfiles = length(invObj.alignedImages);
        fileNames = invObj.fileNames;
        
        plotData = invObj.imgDifffPercent;
        %string(fileNames)
        
        plot(app.UIAxes2, 1:1:nfiles, plotData);
        xticklabels(app.UIAxes2, string(fileNames));
        
        app.UIAxes2.TickLabelInterpreter = "none";
        
        ylabel(app.UIAxes2, "Difference [%]");
        xlabel(app.UIAxes2, "Image Index", "Interpreter","none");
        
    end
%==========================================================================
    function setEnableFilePanel(app, enabled)
        app.HeightPixelEditField.Enable = enabled;
        app.WidthPixelEditField.Enable = enabled;
        app.FileNameEditField.Enable = enabled;
        if ~enabled
            app.HeightPixelEditField.Value = 0;
            app.WidthPixelEditField.Value = 0;
            app.FileNameEditField.Value = "";
        end
    end
%==========================================================================
    function updateFilePanel(app, fName, imgObj)
        app.FileNameEditField.Value = fName;
        [height, width, ~] = size(imgObj);
        app.WidthPixelEditField.Value = width;
        app.HeightPixelEditField.Value = height;
    end
%==========================================================================
    function displayImage(app, tNode)
            if contains(class(tNode.Parent), 'TreeNode')
                 % LOad this file and display the data
                 dirPath = tNode.Parent.NodeData;
                 fName = tNode.NodeData;
                 fullPath = dirPath+""+filesep+fName;
                 if exist(fullPath, "file")
                    
                    cla(app.UIAxes);
                    
                    title(app.UIAxes, fullPath, "Interpreter", "none");
                    
                    img = imread(fullPath);
                    app.setEnableFilePanel(true);
                    app.updateFilePanel(tNode.Text, img);
                    
                    
                    hImage = imshow(img, "Parent", app.UIAxes);
                    % This line below makes the plot refresh much faster!
                    set(hImage,'CData', img);
                    drawnow();
                    
                    app.UIAxes2.Visible = false;

                 end
            else
                app.setEnableFilePanel(false);

                cla(app.UIAxes);
                title(app.UIAxes, "Image to display");
            end
    end
%==========================================================================
        function initIcons(app)
            iconsList = ["./icons/add_icon.png", "./icons/remove_icon.png", "./icons/logo.png"];
            
            app.setIconTo(app.AddButton, iconsList(1));
            app.setIconTo(app.RemoveButton, iconsList(2));
            app.setIconTo(app.UIFigure, iconsList(3));
        end
%==========================================================================        
        function setIconTo(app, uiObj, iconPath)
            if exist(iconPath, "file")
                uiObj.Icon = iconPath;
                if isprop(uiObj, "Text")
                    uiObj.Text = "";
                end
            end
        end
%==========================================================================
        function showMessage(app, msg)
            uialert(app.UIFigure, msg, "Information", "Icon", "info");
        end

%==========================================================================
        
        function updateProcessedPanel(app, fusedImageIndx)
            app.HTML2.Visible = false;
            app.UIAxes.Visible = true;
            
            % If something goes wrong the invObj is an empty char
            invObj = app.Model.lastInvestigation;
            
            if isprop(invObj, "fusedImage") 
                countImage = length(invObj.fusedImage);
                
                fusedImage = invObj.fusedImage{fusedImageIndx};
                cla(app.UIAxes);
                hImage = imshow(fusedImage, "Parent", app.UIAxes);
                
                % This line below makes the plot refresh much faster!
                set(hImage,'CData', fusedImage);
                
                imgName = invObj.imageCellArray{fusedImageIndx};
                imgName = strsplit(imgName, filesep);
                imgName = string(imgName(end));
                
                refImage = invObj.refImageComp;
                refImage = strsplit(refImage, filesep);
                refImage = string(refImage(end));
                
                strTitle = imgName+""+newline+"vs"+""+newline+""+refImage;
                
                title(app.UIAxes, strTitle, "Interpreter","none");
                
                app.Model.currentFuseImageIndex = fusedImageIndx;
                
                if fusedImageIndx >= countImage
                    app.NextButton.Enable = false;
                end
                
                if fusedImageIndx <= 1
                    app.PreviousButton.Enable = false;
                end
                
            end
        end
    end
%==========================================================================   
    methods (Access = public)
        
        function updateProgress(app, progress)
            minProg = app.Model.minProgress;
            maxProg = app.Model.maxProgress;
            
            prgPercent = 100*progress/(maxProg - minProg);
            index = ceil(prgPercent);

            if index <= length(app.colorMapProgress)
                color = app.colorMapProgress(index,:);
                app.ProgressEditField.Value = ""+ceil(prgPercent)+"%";
                app.ProgressEditField.BackgroundColor = color;
                drawnow();
            end
            
        end
    end
%==========================================================================

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.UIFigure.Name = "Computer Vision Challenge 2021 - Group 50";
            app.initIcons()
            app.initColorMapProgress();
            
            % The fullfile command is mandatory!
          
            app.HTML2.HTMLSource = fullfile(pwd,"media/loading.html");
            app.HTML2.Visible = false;
            
            app.Model = UIModel(app);
            
            app.updateViewFromModel();
            
            app.ColorblindfusionCheckBoxValueChanged();
        end

        % Callback function
        function AboutMenuSelected(app, event)
            msg = sprintf("Computer Vision Challenge 2021\n\nDeveloper:\nPaul Zech,\nHinrich Sackmann,\nRobert Ruidisch,\nJohannes Kunz,\nMarkus Kaschke");
            uialert(app.UIFigure, msg, "About", "Icon", "info");
            
        end

        % Callback function
        function ExitMenuSelected(app, event)
            closereq();
        end

        % Button pushed function: AddButton
        function AddButtonPushed(app, event)
            selectedDir = uigetdir();
            drawnow();
            figure(app.UIFigure);
            
            if selectedDir
                [success, msg] = app.Model.addDirToStorage(selectedDir);
                if ~success
                    app.showMessage(msg)
                else
                    app.updateViewFromModel()
                end
                
            end
        end

        % Button pushed function: RemoveButton
        function RemoveButtonPushed(app, event)
            tNode = app.Tree.SelectedNodes;
            if contains(class(tNode.Parent), 'TreeNode')
                tNode = tNode.Parent;
            end
            app.RemoveButton.Enable = false;
            app.Model.removeDirFromStorage(tNode.Text)
            app.updateViewFromModel();
            
        end

        % Value changed function: DirectoryDropDown
        function DirectoryDropDownValueChanged(app, event)
            value = app.DirectoryDropDown.Value;
            if ~isempty(value)
                app.DirectoryDropDown.Tooltip = value;
                
                cellArrayFiles = app.Model.retrieveFilesFromDir(value);
                cellStrs = cellstr(cellArrayFiles);
                fileNames = cell(1,length(cellStrs));
                
                for i = 1:1:length(cellStrs)
                    tmp = strsplit(cellStrs{i}, filesep);
                    tmp = tmp(end);
                    fileNames(i) = tmp;
                end
%                 fun = @(x) x(end-10:end-4);
%                 fileNames = cellfun(fun, cellStrs, 'UniformOutput', false);
                
                app.ReferenceImageDropDown.Items = fileNames;
                app.ReferenceImageDropDown_2.Items = fileNames;
                
                app.Model.selectedDir = value;
                
                app.InvestigateButton.Enable = false;
                app.NextButton.Enable = false;
                app.PreviousButton.Enable = false;
                app.PlayVideoButton.Enable = false;
                
                app.ReferenceImageDropDownValueChanged();
                app.ReferenceImageDropDown_2ValueChanged();
                app.ProgressEditField.Value = "0%";
                color = app.colorMapProgress(1,:);
                app.ProgressEditField.BackgroundColor = color;
                drawnow();
            end
        end

        % Selection changed function: Tree
        function TreeSelectionChanged(app, event)
            tNode = app.Tree.SelectedNodes;
            app.displayImage(tNode);
            app.RemoveButton.Enable = true;
        end

        % Value changed function: ReferenceImageDropDown
        function ReferenceImageDropDownValueChanged(app, event)
            value = app.ReferenceImageDropDown.Value;
            path = app.DirectoryDropDown.Value;
            path = path+""+filesep+""+value;
            
            app.Model.selectedRefImage = path;
            app.ReferenceImageDropDown.Tooltip = value;
            drawnow();
        end

        % Button pushed function: InvestigateButton
        function InvestigateButtonPushed(app, event)
            app.UIAxes.Visible = false;
            app.NextButton.Enable = false;
            app.PreviousButton.Enable = false;
            app.PlayVideoButton.Enable = false;
            
            cla(app.UIAxes);
            cla(app.UIAxes2);
            
            app.UIAxes2.Visible = false;
            app.HTML2.Visible = true;
            drawnow();
            app.Model.startDifferences();
            
            app.updateProcessedPanel(1);
            app.Model.currentFuseImageIndex = 1;
            app.NextButton.Enable = true;
            app.PlayVideoButton.Enable = true;
            
            app.updatePercentagePlot();
        end

        % Value changed function: ReferenceImageDropDown_2
        function ReferenceImageDropDown_2ValueChanged(app, event)
            value = app.ReferenceImageDropDown_2.Value;
            path = app.DirectoryDropDown.Value;

            path = path+""+filesep+""+value;
            
            app.Model.selectedRefImageComp = path;
            
            app.ReferenceImageDropDown_2.Tooltip = value;
            drawnow();
        end

        % Button pushed function: AlignImagesButton
        function AlignImagesButtonPushed(app, event)
            
            success = app.Model.startAlignment();
            if success
                app.InvestigateButton.Enable = true;
            else
                app.InvestigateButton.Enable = false;
            end
            
        end

        % Button pushed function: NextButton
        function NextButtonPushed(app, event)
            invObj = app.Model.lastInvestigation;
            countImages = length(invObj.fusedImage);
            crtIndex = app.Model.currentFuseImageIndex;
            
            app.updateProcessedPanel(crtIndex+1)
            if crtIndex+1 >= countImages
                app.NextButton.Enable = false;
            end
            app.PreviousButton.Enable = true;
        end

        % Button pushed function: PreviousButton
        function PreviousButtonPushed(app, event)
            crtIndex = app.Model.currentFuseImageIndex;
            
            app.updateProcessedPanel(crtIndex-1)
            if crtIndex-1 <= 1
                app.PreviousButton.Enable = false;
            end
            app.NextButton.Enable = true;
        end

        % Value changed function: ColorblindfusionCheckBox
        function ColorblindfusionCheckBoxValueChanged(app, event)
            value = app.ColorblindfusionCheckBox.Value;
            app.Model.colorBlind = value;
        end

        % Button pushed function: PlayVideoButton
        function PlayVideoButtonPushed(app, event)
             app.Model.playVideo();
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 1376 915];
            app.UIFigure.Name = 'MATLAB App';

            % Create UIAxes
            app.UIAxes = uiaxes(app.UIFigure);
            title(app.UIAxes, 'Image to display')
            app.UIAxes.Position = [295 210 1082 706];

            % Create UIAxes2
            app.UIAxes2 = uiaxes(app.UIFigure);
            app.UIAxes2.Visible = 'off';
            app.UIAxes2.Position = [299 12 1073 185];

            % Create DataSelectionPanel
            app.DataSelectionPanel = uipanel(app.UIFigure);
            app.DataSelectionPanel.Title = 'Data Selection';
            app.DataSelectionPanel.Position = [1 508 287 408];

            % Create Tree
            app.Tree = uitree(app.DataSelectionPanel);
            app.Tree.SelectionChangedFcn = createCallbackFcn(app, @TreeSelectionChanged, true);
            app.Tree.Position = [8 188 212 198];

            % Create AddButton
            app.AddButton = uibutton(app.DataSelectionPanel, 'push');
            app.AddButton.ButtonPushedFcn = createCallbackFcn(app, @AddButtonPushed, true);
            app.AddButton.Tooltip = {'Adds a  directory to the list'};
            app.AddButton.Position = [222 364 56 22];
            app.AddButton.Text = 'Add';

            % Create RemoveButton
            app.RemoveButton = uibutton(app.DataSelectionPanel, 'push');
            app.RemoveButton.ButtonPushedFcn = createCallbackFcn(app, @RemoveButtonPushed, true);
            app.RemoveButton.Enable = 'off';
            app.RemoveButton.Tooltip = {'Removes the selected directory from the list'};
            app.RemoveButton.Position = [222 332 56 22];
            app.RemoveButton.Text = 'Remove';

            % Create ReferenceImageDropDownLabel
            app.ReferenceImageDropDownLabel = uilabel(app.DataSelectionPanel);
            app.ReferenceImageDropDownLabel.HorizontalAlignment = 'right';
            app.ReferenceImageDropDownLabel.Position = [4 122 98 22];
            app.ReferenceImageDropDownLabel.Text = 'Reference Image';

            % Create ReferenceImageDropDown
            app.ReferenceImageDropDown = uidropdown(app.DataSelectionPanel);
            app.ReferenceImageDropDown.Items = {};
            app.ReferenceImageDropDown.ValueChangedFcn = createCallbackFcn(app, @ReferenceImageDropDownValueChanged, true);
            app.ReferenceImageDropDown.Tooltip = {'This image is taken as reference image for alignment'};
            app.ReferenceImageDropDown.Position = [116 122 163 22];
            app.ReferenceImageDropDown.Value = {};

            % Create DirectoryDropDownLabel
            app.DirectoryDropDownLabel = uilabel(app.DataSelectionPanel);
            app.DirectoryDropDownLabel.HorizontalAlignment = 'right';
            app.DirectoryDropDownLabel.Position = [4 153 54 22];
            app.DirectoryDropDownLabel.Text = 'Directory';

            % Create DirectoryDropDown
            app.DirectoryDropDown = uidropdown(app.DataSelectionPanel);
            app.DirectoryDropDown.Items = {};
            app.DirectoryDropDown.ValueChangedFcn = createCallbackFcn(app, @DirectoryDropDownValueChanged, true);
            app.DirectoryDropDown.Tooltip = {'The directory containing images to inspect'};
            app.DirectoryDropDown.Position = [73 153 207 22];
            app.DirectoryDropDown.Value = {};

            % Create AlignImagesButton
            app.AlignImagesButton = uibutton(app.DataSelectionPanel, 'push');
            app.AlignImagesButton.ButtonPushedFcn = createCallbackFcn(app, @AlignImagesButtonPushed, true);
            app.AlignImagesButton.Tooltip = {'Aligns the images in the selected directory'};
            app.AlignImagesButton.Position = [89 81 100 22];
            app.AlignImagesButton.Text = 'Align Images';

            % Create ProgressEditField
            app.ProgressEditField = uieditfield(app.DataSelectionPanel, 'text');
            app.ProgressEditField.Editable = 'off';
            app.ProgressEditField.HorizontalAlignment = 'center';
            app.ProgressEditField.FontColor = [1 1 1];
            app.ProgressEditField.BackgroundColor = [1 0 0];
            app.ProgressEditField.Tooltip = {'Progress of alignment'};
            app.ProgressEditField.Position = [9 48 265 22];
            app.ProgressEditField.Value = '0%';

            % Create SelectedImagePanel
            app.SelectedImagePanel = uipanel(app.UIFigure);
            app.SelectedImagePanel.Title = 'Selected Image';
            app.SelectedImagePanel.Position = [1 335 287 151];

            % Create FileNameEditFieldLabel
            app.FileNameEditFieldLabel = uilabel(app.SelectedImagePanel);
            app.FileNameEditFieldLabel.HorizontalAlignment = 'right';
            app.FileNameEditFieldLabel.Position = [1 95 60 22];
            app.FileNameEditFieldLabel.Text = 'File Name';

            % Create FileNameEditField
            app.FileNameEditField = uieditfield(app.SelectedImagePanel, 'text');
            app.FileNameEditField.Editable = 'off';
            app.FileNameEditField.Enable = 'off';
            app.FileNameEditField.Position = [76 95 201 22];

            % Create WidthPixelLabel
            app.WidthPixelLabel = uilabel(app.SelectedImagePanel);
            app.WidthPixelLabel.HorizontalAlignment = 'right';
            app.WidthPixelLabel.Position = [1 55 79 22];
            app.WidthPixelLabel.Text = 'Width [Pixel] ';

            % Create WidthPixelEditField
            app.WidthPixelEditField = uieditfield(app.SelectedImagePanel, 'numeric');
            app.WidthPixelEditField.Editable = 'off';
            app.WidthPixelEditField.Enable = 'off';
            app.WidthPixelEditField.Position = [112 55 165 22];

            % Create HeightPixelEditFieldLabel
            app.HeightPixelEditFieldLabel = uilabel(app.SelectedImagePanel);
            app.HeightPixelEditFieldLabel.HorizontalAlignment = 'right';
            app.HeightPixelEditFieldLabel.Position = [1 22 76 22];
            app.HeightPixelEditFieldLabel.Text = 'Height [Pixel]';

            % Create HeightPixelEditField
            app.HeightPixelEditField = uieditfield(app.SelectedImagePanel, 'numeric');
            app.HeightPixelEditField.Editable = 'off';
            app.HeightPixelEditField.Enable = 'off';
            app.HeightPixelEditField.Position = [112 22 165 22];

            % Create InvestigatePanel
            app.InvestigatePanel = uipanel(app.UIFigure);
            app.InvestigatePanel.Title = 'Investigate';
            app.InvestigatePanel.Position = [2 12 286 324];

            % Create InvestigateButton
            app.InvestigateButton = uibutton(app.InvestigatePanel, 'push');
            app.InvestigateButton.ButtonPushedFcn = createCallbackFcn(app, @InvestigateButtonPushed, true);
            app.InvestigateButton.Enable = 'off';
            app.InvestigateButton.Tooltip = {'Start the investigation of the aligned images'};
            app.InvestigateButton.Position = [31 81 100 22];
            app.InvestigateButton.Text = 'Investigate';

            % Create ReferenceImageDropDown_2Label
            app.ReferenceImageDropDown_2Label = uilabel(app.InvestigatePanel);
            app.ReferenceImageDropDown_2Label.HorizontalAlignment = 'right';
            app.ReferenceImageDropDown_2Label.Position = [7 249 98 22];
            app.ReferenceImageDropDown_2Label.Text = 'Reference Image';

            % Create ReferenceImageDropDown_2
            app.ReferenceImageDropDown_2 = uidropdown(app.InvestigatePanel);
            app.ReferenceImageDropDown_2.Items = {};
            app.ReferenceImageDropDown_2.ValueChangedFcn = createCallbackFcn(app, @ReferenceImageDropDown_2ValueChanged, true);
            app.ReferenceImageDropDown_2.Tooltip = {'Set the reference image for investigation.'};
            app.ReferenceImageDropDown_2.Position = [113 249 159 22];
            app.ReferenceImageDropDown_2.Value = {};

            % Create PreviousButton
            app.PreviousButton = uibutton(app.InvestigatePanel, 'push');
            app.PreviousButton.ButtonPushedFcn = createCallbackFcn(app, @PreviousButtonPushed, true);
            app.PreviousButton.Enable = 'off';
            app.PreviousButton.Position = [8 34 100 22];
            app.PreviousButton.Text = 'Previous';

            % Create NextButton
            app.NextButton = uibutton(app.InvestigatePanel, 'push');
            app.NextButton.ButtonPushedFcn = createCallbackFcn(app, @NextButtonPushed, true);
            app.NextButton.Enable = 'off';
            app.NextButton.Position = [178 34 100 22];
            app.NextButton.Text = 'Next';

            % Create ColorblindfusionCheckBox
            app.ColorblindfusionCheckBox = uicheckbox(app.InvestigatePanel);
            app.ColorblindfusionCheckBox.ValueChangedFcn = createCallbackFcn(app, @ColorblindfusionCheckBoxValueChanged, true);
            app.ColorblindfusionCheckBox.Text = 'Color blind fusion';
            app.ColorblindfusionCheckBox.Position = [8 216 265 22];

            % Create PlayVideoButton
            app.PlayVideoButton = uibutton(app.InvestigatePanel, 'push');
            app.PlayVideoButton.ButtonPushedFcn = createCallbackFcn(app, @PlayVideoButtonPushed, true);
            app.PlayVideoButton.Enable = 'off';
            app.PlayVideoButton.Position = [155 81 100 22];
            app.PlayVideoButton.Text = 'Play Video';

            % Create HTML2
            app.HTML2 = uihtml(app.UIFigure);
            app.HTML2.Position = [295 12 1071 904];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = cv_gui_main

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end