function [I_cell_rgb, imagefiles] = data_loader(folder)
% Loads all images in a cell array out of a provided folder

imagefiles = dir(['Datasets/' folder '/*.jpg']);
nfiles = length(imagefiles);

I_cell_rgb = cell(1, nfiles);
for i=1:nfiles
    I_cell_rgb{i} = imread(['Datasets/' folder '/' imagefiles(i).name]);
end
end

