%% align_iamges_iterative
% Input arguments:
% I_cell_rgb: cell array of all images
% n_ref: index of the reference image that all other images are aligned to
% prgCallback: call back for the progress bar in the GUI
% Output arguments:
% I_aligned_rgb: cell array of aligned rgb images
% I_aligned: cell array of aligned grayscale images
% successful_indices: indices of successfully aligned images
function [I_aligned_rgb, I_aligned, successful_indices] = align_images_iterative(I_cell_rgb, n_ref, prgCallback)

%% setup
N = length(I_cell_rgb);

% convert to grayscale
I_ref = rgb2gray(I_cell_rgb{n_ref});

unaligned_indices = [1:n_ref-1 n_ref+1:N];
I_unaligned = cell(1,N-1);
I_unaligned_rgb = I_cell_rgb(unaligned_indices);
j = 1;
for i=unaligned_indices
    rgb_image = I_cell_rgb{i};
%     rgb_image(:,:,1) = imhistmatch(rgb_image(:,:,1), I_cell_rgb{n_ref}(:,:,1));
%     rgb_image(:,:,2) = imhistmatch(rgb_image(:,:,2), I_cell_rgb{n_ref}(:,:,2));
%     rgb_image(:,:,3) = imhistmatch(rgb_image(:,:,3), I_cell_rgb{n_ref}(:,:,3));
    I_unaligned{j} = rgb2gray(rgb_image);
    j = j+1;
end

I_aligned = {I_ref};
I_aligned_rgb = I_cell_rgb(n_ref);
aligned_indices = n_ref;

% storage for features and points of interest
features_unaligned = cell(1, N-1);
features_aligned = cell(1, N);
feature_points_unaligned = cell(1, N-1);
feature_points_aligned = cell(1, N);

% match brightness and contrast to initial reference image
for i=1:N-1
    I_unaligned{i} = imhistmatch(I_unaligned{i}, I_ref);
end

%% iterative alignment algorithm
% init loop variables
aligned_all = 1;
n = 1;
count = 0;

% set status bar to the first step (reference image is already aligned)
prgCallback(1);

while length(I_aligned) <  N
    newly_aligned = {};
    
    % iterate over all input images except the initial reference
    for i = 1:N-1
        I = I_unaligned{i};
        
        % skip, if the image has already been aligned
        if length(I_unaligned{i}) == 1
            continue
        end
        
        % iterate over all newly added aligned/reference images
        done = 0;
        for j = n:length(I_aligned)
            ref = I_aligned{j};
            
            % try to match the image to the current reference image:
            
            % load features and points of interest from storage
            features1 = features_unaligned{i}; 
            feature_points1 = feature_points_unaligned{i};
            features2 = features_aligned{j}; 
            feature_points2 = feature_points_aligned{j};
            
            % try to align the image and the reference
            [aligned_image, success, H, features1, features2, feature_points1, feature_points2] = align_image(I, ref, features1, features2, feature_points1, feature_points2, 0.4);

            % write features and points of interest to storage
            features_unaligned{i} = features1; 
            feature_points_unaligned{i} = feature_points1;
            features_aligned{j} = features2; 
            feature_points_aligned{j} = feature_points2;
            
            % print which image has been aligned to which reference
            disp(['compare ' num2str(unaligned_indices(i)) ' to ' num2str(aligned_indices(j))])
            
            % check if the alignment procedure was successful
            if success
                % transform the rgb image
                tform = projective2d(H');
                aligned_image_rgb = imwarp(I_unaligned_rgb{i}, tform, 'OutputView', imref2d(size(ref)));
                I_aligned_rgb = [I_aligned_rgb {aligned_image_rgb}];
                
                % update the progress bar
                prgCallback(length(I_aligned_rgb));
                
                % stop searching for alignments
                done = 1;
                break;
            end
        end
        
        if done % successfully aligned index i
            disp(['matched image ' num2str(unaligned_indices(i))]);
            
            % mark image as aligned
            I_unaligned{i} = 0;
            count = count+1;
            prgCallback(count);
            
            % add image to cell of newly aligned images
            newly_aligned = [newly_aligned {aligned_image}];
            aligned_indices = [aligned_indices unaligned_indices(i)];
        end
    end
    
    % check if any new images  could be aligned in the current iteration,
    % if not, no further image matched can be made -> stop the algorithm
    if isempty(newly_aligned)
        warning("could  not register all images")
        aligned_all = 0;
        break
    end
    
    % append cell newly aligned images to cell of aligned images
    n = length(I_aligned)+1;
    I_aligned = [I_aligned newly_aligned];
end


%% reorder images
% images may not be in chronological order after the matching procedure
% -> reorder
order = zeros(1,length(aligned_indices));
successful_indices = zeros(1,length(aligned_indices));
j = 1;
for i = 1:N
    index = find(aligned_indices == i);
    if isempty(index)
        continue
    end
    successful_indices(j) = i;
    order(j) = index;
    j = j+1;
end

I_aligned = I_aligned(order);
I_aligned_rgb = I_aligned_rgb(order);

