%% euclidean_dist
% Input arguments:
% H: homography matrix
% x1h: homogeneous pixel coordinates of the feature points in the first images
% x2h: homogeneous pixel coordinates of the feature points in the second images
% Output arguments:
% d: array with the distances

% compute the euclidean distance of the projected feature points in image 1
% to the feature points in image 2
function d = euclidean_dist(H, x1h, x2h)
    x = H*x1h;
    x = x ./ (ones(3,1) * x(3,:));   
    d = vecnorm(x - x2h);
end

