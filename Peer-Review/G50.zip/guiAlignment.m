function success = guiAlignment(invObj, uiModel)
% Connector: GUI <--> Alignment

    % This method updates the progess on the GUI
    prgCallback = @(x) uiModel.updateProgress(x);

    % Choosen reference image
    nfiles = length(invObj.imageCellArray);
    refImage = invObj.refImage;
    findNRef = @(x) strcmp(x,refImage);
    n_ref = find(cellfun(findNRef, invObj.imageCellArray));
   
    %% Load the images
    I_cell_rgb = cell(1, nfiles);
    for i=1:nfiles
        filePath = invObj.imageCellArray{i};
        I_cell_rgb{i} = imread(filePath);
    end

    %% Align images
    [aligned_images_rgb, aligned_images, successful_indices] =...
                     align_images_iterative(I_cell_rgb, n_ref, prgCallback);
    
    % Save the data to invObj Class
    invObj.success = true;
    invObj.alignedImages = aligned_images;
    invObj.alignedImagesRGB = aligned_images_rgb;
    invObj.successfulIndices = successful_indices;
    success = true;
end
