function [diffImage] = difference_calculation(aligned_images,compare_ref,colorBlind)
% This function visualizes the differences between the reference image and
% all other images

% Reference image
A = aligned_images{compare_ref};
% Detect black border around the image from alignment
black_a = A<=1;

nfiles = length(aligned_images);   
for i=1:nfiles

        % Load image
        B = aligned_images{i}; 
        % Detect black border around the image from alignment
        black_b = B<=1;

        % Overlap the pictures for displaying difference
        if ~colorBlind
            img = imfuse(A, B,...
                                   'falsecolor', 'ColorChannels', 'red-cyan');
        else
            img = imfuse(A, B,...
                                   'falsecolor', 'ColorChannels', 'green-magenta');
        end

        % Crop the black corner
        img(black_a) = 0;
        img(black_b) = 0;

        % Save the image
        diffImage{i} = img;
end
end

