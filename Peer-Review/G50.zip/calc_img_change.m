function diff_result = calc_img_change(alignedImages, refImageComp)
% Calculate the change in percent from selected reference image to the other images

nfiles = length(alignedImages);

ref = alignedImages{refImageComp};


mask = ones(size(ref)) == 1;


% Reference Image
A = alignedImages{refImageComp};
nblack2 = A>1; 

for i=1:nfiles
    A = alignedImages{i};
    mask = and(mask,A>0);
end
not_black = find(mask);
diff_result = 1:nfiles;

for i=1:nfiles
    A = alignedImages{i}; 
    
    img = (imfuse(imgaussfilt(A), imgaussfilt(ref), 'diff') > 10) *1; 
    brightness = mean(img(not_black)); 
    
    abs_per_change = brightness; 

    diff_result(i) = abs_per_change * 100;  
end


% Plot the result
% if plot_flag
%     figure; 
%     plot(diff_result, '*-'); 
%     set(gca,'TickLabelInterpreter','none')
%     xname=cell(1,length(imagefiles));
%     for i=1:length(imagefiles) 
%         xname{i}=imagefiles(i).name(1:end-4);
%     end
%     xticklabels(xname); 
%     xtickangle(45)
%     xlabel('date [yyyy_mm]','Interpreter','none')
%     ylabel('difference [%]')
%     grid on 
%     title('Change to reference picture in the overlapping region')
% end


end
