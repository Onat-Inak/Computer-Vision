%% FourPointAlgo
% implementation of the Four Point Algorithm
% Input arguments:
% x1h: feature points in image 1
% x2h: feature points in image 2
% Output:
% H: estimated homography matrix

function [H] = FourPointAlgo(x1h,x2h)

N = size(x1h,2);
A = zeros(3*N,9);


for i=1:N
    A(3*i-2:3*i,:) = [x1h(1,i)*hat(x2h(:,i)), x1h(2,i)*hat(x2h(:,i)), x1h(3,i)*hat(x2h(:,i))];
end

[~,~,V] = svd(A);

HL = reshape(V(:,9),3,3);

[~,S,~] = svd(HL);

H = HL ./ S(2,2);

d = dot(x2h(:,i), H * x1h(:,i));

if length(find(d < 0)) > N / 2
    H = -H;
end

end

