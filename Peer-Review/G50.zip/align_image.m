%% align_image
% this function aligns two grayscale images
% Input arguments:
% I: unaligned grayscale image
% I_ref: grayscale reference image
% features: cached features of the unaligned image
% features_ref: cached features of the reference image
% valid_points: cached valid points of the unaligned image
% valid_points_ref: cached valid points of the reference image
% max_ratio: parameter controlling the minimum quality of the matches
% Outputs:
% aligned_image: aligned grayscale image
% succeded: flag if the alignment was successful
% H: computed homography matrix
% features, features_ref, valid_points, valid_points_ref: values to be cached

function [aligned_image, succeded, H, features, features_ref, valid_points, valid_points_ref] = align_image(I, I_ref, features, features_ref,  valid_points, valid_points_ref, max_ratio)

    % compute the SURF feature points, if they have not been cached so far
    if isempty(features)
        points = detectSURFFeatures(I, 'MetricThreshold', 400.);
        [features,valid_points] = extractFeatures(I,points);
    end
    
    if isempty(features_ref)
        points_ref = detectSURFFeatures(I_ref, 'MetricThreshold', 400.);
        [features_ref,valid_points_ref] = extractFeatures(I_ref,points_ref);
    end
    
    % match the feature points
    indexPairs = matchFeatures(features,features_ref, 'Method', 'Exhaustive', 'Unique', true, 'MatchThreshold', 1., 'MaxRatio', max_ratio); %
        
    matchedPoints1 = valid_points(indexPairs(:,1),:);
    matchedPoints2 = valid_points_ref(indexPairs(:,2),:);

    x1 = double(matchedPoints1.Location');
    x2 = double(matchedPoints2.Location');

    % transform the pixel coordinates of the matched feature points to
    % homogoeneous coordinates
    N = size(x1, 2);
    x1h = [x1; ones(1,N)];
    x2h = [x2; ones(1,N)];

    %% RANSAC algorithm
    
    % if less than four features could be matched, image registration is
    % not possible -> return
    if N < 4
        warning('Could not find enough matches.');
        succeded = 0;
        aligned_image = 0;
        H = eye(3);
        return
    else
        [H, largest_set_size] = ransac(x1h,x2h,'tolerance', 10., 'k', min(8, max(floor(N*0.8),4)), 'p', 0.99);
    end
    
    % check if the image alignment was successful by evaluating the
    % success criterion
    d = euclidean_dist(H,x1h, x2h);
    succeded = length(find(d < 30)) > max(length(d) * 0.06, 8);
    
    % if the alignemnt was successful, project the unaligned grayscale image
    if succeded
        tform = projective2d(H');
        aligned_image = imwarp(I, tform, 'OutputView', imref2d(size(I_ref)));
    else
        aligned_image = 0;
    end
end