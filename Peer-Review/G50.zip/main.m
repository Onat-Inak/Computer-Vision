% Start the GUI
cv_gui_main()

% If you have problems starting or executing the GUI you can take a look at
% the live sript geoCompare.mlx. It provides the same features as GUI but
% in a live script.