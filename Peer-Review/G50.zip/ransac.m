%% ransac
% implementation of ransac as implemented in the homework
% the sampson distances has been replaced by the euclidean distance
% Input arguments:
% x1h: homogeneous pixel coordinates in image one
% x2h: homogeneous pixel coordinates in image two
% varargin: parameters
% Outputs:
% largest_set_H: best fitting homography matrix H
% largest_set_size: number of pairs that consent with H


function [largest_set_H, largest_set_size] = ransac(x1h,x2h,varargin)

p = inputParser;
validE = @(x) isnumeric(x) && isscalar(x) && (x > 0) && (x < 1);
validP = @(x) isnumeric(x) && isscalar(x) && (x > 0) && (x < 1);
validT = @(x) isnumeric(x) && isscalar(x);
validk = @(x) isnumeric(x) && isscalar(x);

addParameter(p, 'epsilon', 0.5, validE);
addParameter(p, 'p', 0.5, validP);
addParameter(p, 'tolerance', 10., validT);
addParameter(p, 'k', 10, validk);

parse(p,varargin{:});

epsilon = p.Results.epsilon;
tolerance = p.Results.tolerance;
k = p.Results.k;
p = p.Results.p;

N = size(x1h,2);

s = log(1-p) / log(1 - (1 - epsilon)^k);
largest_set_size = 0;
largest_set_dist = Inf;
largest_set_H = zeros(3);
best_consenus_set = 0;

for i=1:s
    rand_shuffle = randperm(N);
    pointIndices = rand_shuffle(1:floor(k));
    H = FourPointAlgo(x1h(:,pointIndices), x2h(:,pointIndices));
    sd = euclidean_dist(H, x1h, x2h);
    consensus_set = sd < tolerance;
    num_curr = length(find(consensus_set));
    cur_sum = sum(sd(consensus_set));
    if num_curr > largest_set_size
        largest_set_size = num_curr;
        largest_set_dist = cur_sum; % ?
        largest_set_H = H;
        best_consenus_set = consensus_set;
    elseif num_curr == largest_set_size
        if largest_set_dist > cur_sum
            largest_set_dist = cur_sum;
            largest_set_H = H;
            best_consenus_set = consensus_set;
        end
    end
end

end

