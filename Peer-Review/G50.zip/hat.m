%% hat
% helper function for the cross product matrix of a vector
function H = hat(v)
    H = [0 -v(3) v(2); v(3) 0 -v(1); -v(2) v(1) 0];
end

