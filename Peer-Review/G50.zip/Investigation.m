classdef Investigation < handle
    % Data Safe for the GUI
    
    properties
        imageCellArray
        fusedImage
        
        refImage
        refImageComp
        rootDir
        
        imgDifffPercent
        fileNames
        
        date
        success
        alignedImages
        successfulIndices
        alignedImagesRGB
        colorBlind
    end
    
    methods
        function self = Investigation()
            
        end
    end
end

