Computer Vision Challenge
========

by Emre Özbas
	Group Number 13 (G13) 

Instructions
------------

User has to give 2 images as inputs for comparison in the top part of the code,
which is indicated in the code with "Enter Image Paths Here" (line 11).
The input should follow the following form: 
	
    "img1 = imread(fullfile([FolderName], [fileNameWithExtension]));"

This is also indicated in the same top part of the code (lines 12 and 13). The 2 
default images are '1990_12.jpg' and '1995_12.jpg' under the folder "Dubai".


Additionally, there are 2 variables which can be changed:
	minPairedFeatureCount: minimum value = 3, recommended values= 3,4,5. When this value is changed
                           between these 3 values, the performance varies greatly. Usually, only
                           one value is the best suited for a set of input images.
	minNonzeroElementCount: Lower values result in less number of difference pixels in the mask, 
				resulting in less number of differences depicted in the final plots.

There is also another code called "mainAlt.m", which is an alternative version to main.m, where 
the minPairedFeatureCount is selected dynamically by a heuristic function called "findBestPairedCount".
With the help of this heuristic function, the minPairedFeatureCount is determined dynamically
(according to the input image).

This alternative code "mainAlt.m" could be -when developed further- useful in the future.

Please consider "main.m" as the main code for evaluation.

Figures
------------
After running the main.m code (press F5 for default), the first figure will depict both input
images, side by side, and the matching SURF features.

Second figure overlays the second image on the first one, so that both images show the same areas,
while the differences are emphasized because of the color difference of the layers.

Last figure depicts 4 images: Top row shows the 2 input images, while the bottom left image is the
absolute differences between the images and the bottom right one is the first input image, overlayed
with the differences.

Installation and Requirements
-----------------------------

Following toolboxes are required:
toolbox             :  \images\images\affine2d.m
toolbox             :  \images\images\fitgeotrans.m
toolbox             :? Multiple class methods match imabsdiff.m
toolbox             :  \images\images\imfuse.m
toolbox             :  \images\images\imhistmatch.m
toolbox             :  \images\images\imref2d.m
toolbox             :? Multiple class methods match imwarp.m
toolbox             :  \vision\vision\detectSURFFeatures.m
toolbox             :  \vision\vision\extractFeatures.m
toolbox             :  \vision\vision\matchFeatures.m
toolbox             :  \vision\vision\showMatchedFeatures.m
