function bestMinPairedFeatureCount = findBestPairedCount(img1, img2)
%takes 2 images as input, returns the best minPairedFeatureCount value
%using a heruristic function below.

im1Points = detectSURFFeatures(img1);
im2Points = detectSURFFeatures(img2);

error = zeros(3,1); %initializing

for i = 1:3 % try all the values 3, 4 and 5 for minPairedFeatureCount, find the best with the heuristic function below
    minPairedFeatureCount = i+2; % minimum value = 3, recommended values = 3,4,5
    featureCount = 0;
    indexPairs = 0;  %initializing number of features paired between the two images
    timerVal = tic;
    while (length(indexPairs) < minPairedFeatureCount && toc(timerVal) < 60)
        try
            featureCount = featureCount + 10; %this loop will increase number of features taken into consideration until the number of paired features reach a minimum number (default:3)
            [features1,valid_points1] = extractFeatures(img1, im1Points.selectStrongest(featureCount));
            [features2,valid_points2] = extractFeatures(img2, im2Points.selectStrongest(featureCount));
            
            matchFeatures(features1, features2, 'Unique', true);
            indexPairs = matchFeatures(features1,features2);
            matchedPoints1 = valid_points1(indexPairs(:,1),:);
            matchedPoints2 = valid_points2(indexPairs(:,2),:);
        catch
            featureCount = featureCount + 1; %in case an error occures because of the small starting value of "featureCount"
        end
    end
    %% Deleting Edges Which Are Not Available On The Second Image (Second Time)
    tform = fitgeotrans(matchedPoints2.Location,matchedPoints1.Location,'nonreflectivesimilarity'); %calculating transformation matrix
    Roriginal = imref2d(size(img1));
    im2t = imwarp(img2,tform,'OutputView',Roriginal); % applying tform on second image (rotation, scaling and translation)
    
    %     deleteEdges = im2t; %initializing
    %     deleteEdges(deleteEdges ~= 0) = 1; %edges of the image (parts of the first image, which are not included in the second image) should be not considered further
    %     im1_b = img1.*deleteEdges;          %so we cut these parts out of the first image, storing the resulting image in im1_b
    tformInv = invert(tform);
    Tinv = tformInv.T;
    ss = Tinv(2,1);
    sc = Tinv(1,1); %used for calculating scale and rotation angle
    scale = sqrt(ss*ss + sc*sc); %scale of the transforation (zoomed in/ out?)
    
    %Heuristic Function
    error(i) = sum(sum(imabsdiff(img1,im2t)));%Adds all the difference values together to create an error sum, similar
    %to the error in machine learning algorithms
end
minval = min(error); %get the minPairedFeatureCount which results in the least "error"
I = find(error==minval,1,'last');

bestMinPairedFeatureCount = I + 2;