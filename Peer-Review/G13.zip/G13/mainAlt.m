%% Computer Vision Challenge
% Emre Özbas (G13)

% Alternative (experimental) version for dynamic "minPairedFeatureCount",
% using the function "findBestPairedCount"

%Please consider "main.m" for evaluation.

%% Setup & Preparation
clear
clc
close all

%Enter Image Paths Here
img1 = imread(fullfile('Dubai', '1990_12.jpg')); %img1 = imread(fullfile([FolderName], [fileNameWithExtension]));
img2 = imread(fullfile('Dubai', '1995_12.jpg'));
im1 = im2gray(img1); %converting to grayscale for simpler calculations
im2 = im2gray(img2);

%% Feature Matching (First Time for Rotation Angle Calculations)
im1Points = detectSURFFeatures(im1); %detecting SURF features in the first image
im2Points = detectSURFFeatures(im2); %detecting SURF features in the second image

timerVal = tic;
indexPairs = 0;  %initializing number of features paired between the two images
featureCount = 0; % decreasing this value results in better performance if the 2 images are similar. However,
% the program may not match any features between 2 images if the number of features are too small.
% That is why I am creating the if statement below:
minPairedFeatureCount = findBestPairedCount(im1, im2) % minimum value = 3, recommended values = 3,4,5
while (length(indexPairs) < minPairedFeatureCount && toc(timerVal) < 15)
    try
        featureCount = featureCount + 10; %this loop will increase number of features taken into consideration until the number of paired features reach a minimum number (default:3)
        [features1,valid_points1] = extractFeatures(im1, im1Points.selectStrongest(featureCount));
        [features2,valid_points2] = extractFeatures(im2, im2Points.selectStrongest(featureCount)); % extracting features from images, number of features increases by each loop until desired number of feature pairs reached
        
        indexPairs = matchFeatures(features1,features2,'Unique', true); % matching features between images
        matchedPoints1 = valid_points1(indexPairs(:,1),:); % storing matched points from the first image
        matchedPoints2 = valid_points2(indexPairs(:,2),:); % storing matched points from the second image
    catch
        featureCount = featureCount + 1; %in case an error occures because of the small starting value of "featureCount"
    end
end

%% Rotation Angle Calculation
tform = fitgeotrans(matchedPoints2.Location,matchedPoints1.Location,'nonreflectivesimilarity'); %calculating transformation matrix

tformInv = invert(tform);
Tinv = tformInv.T;
ss = Tinv(2,1);
sc = Tinv(1,1); %used for calculating scale and rotation angle
scale = sqrt(ss*ss + sc*sc); %scale of the transforation (zoomed in/ out?)
theta = atan2(ss,sc)*180/pi; %rotation angle of the transformation

Roriginal = imref2d(size(im1));
im2t = imwarp(im2,tform,'OutputView',Roriginal); % applying tform on second image (rotation, scaling and translation)

%% Deleting Edges Which Are Not Available on The Second Image
deleteEdges = im2t; %initializing
deleteEdges(deleteEdges ~= 0) = 1; %edges of the image (parts of the first image, which are not included in the second image) should be not considered further
im1_a = im1.*deleteEdges;          %so we cut these parts out of the first image, storing the resulting image in im1_a

%% Feature Mathing 2nd Time
%Same steps as the first time. Only difference is that the parts which are
%not available in the other image are cut out in im1_a (made possible by being able
%to overlay 2 images, which was made possible by having the transformation
%matrix at hand), so these are not considered for feature extraction -> less noise

minPairedFeatureCount = findBestPairedCount(im1_a, im2) % minimum value = 3, recommended values = 3,4,5
while (length(indexPairs) < minPairedFeatureCount && toc(timerVal) < 15)
    try
        featureCount = featureCount + 10;
        im1Points = detectSURFFeatures(im1_a);
        im2Points = detectSURFFeatures(im2);
        
        [features1,valid_points1] = extractFeatures(im1_a, im1Points.selectStrongest(featureCount));
        [features2,valid_points2] = extractFeatures(im2, im2Points.selectStrongest(featureCount));
        
        matchFeatures(features1, features2, 'Unique', true);
        indexPairs = matchFeatures(features1,features2);
        matchedPoints1 = valid_points1(indexPairs(:,1),:);
        matchedPoints2 = valid_points2(indexPairs(:,2),:);
        
        tform = fitgeotrans(matchedPoints2.Location,matchedPoints1.Location,'nonreflectivesimilarity');
        Roriginal = imref2d(size(im1));
        im2t = imwarp(im2,tform,'OutputView',Roriginal);
    catch
        featureCount = featureCount + 1; %in case an error occures because of the small starting value of "featureCount"
    end
end
    %% Deleting Edges Which Are Not Available On The Second Image (Second Time)
    deleteEdges = im2t; %initializing
    deleteEdges(deleteEdges ~= 0) = 1; %edges of the image (parts of the first image, which are not included in the second image) should be not considered further
    im1_b = im1.*deleteEdges;          %so we cut these parts out of the first image, storing the resulting image in im1_b
    
    %% Unmatched Features
    unmatchedPoints1 = valid_points1; %initializing unmatchedPoints1
    unmatchedPoints1(indexPairs(:,1)) = [];
    
    %% Comparison by Overlay
    figure;
    showMatchedFeatures(im1,im2,matchedPoints1,matchedPoints2, 'montage'); %showing feature matching
    title("Matched Features");
    figure;
    blend = imfuse(im1,im2t,'falsecolor', 'ColorChannels', [1 2 0]); %overlaying 2 images, showing the differences
    imshow(blend); hold on;
    plot(unmatchedPoints1.selectStrongest(10)); %plotting the features of the first image which were not matched
    title("Overlayed Images, Depicting Unmatched Features from Image 1");
    
    %% Comparison by Absolute Difference
    mask = im1_b*0; %initializing mask image to mask out similar points
    treshLoc = 0; %higher the value, lower the pixel value treshold, namely the treshold for difference
    minNonzeroElementCount = 1000*sqrt(featureCount); % Lower values result in less number of difference pixels in the mask.
    % (I used featureCount here since it enables a dynamic function for different image inputs)
    while(nnz(mask) < minNonzeroElementCount) %loop until nonzero elements in the mask are sufficiently numerous enough
        treshLoc = treshLoc + 150;
        mask = imabsdiff(im1_b,im2t); % creating a binary mask to leave out differences between 2 images
        A = mask';
        A = A(:)'; %converting matrix to 1-dim array for convenience
        xs = sort(A,'descend'); %sort from biggest difference to the smallest
        tresh = xs(treshLoc); % setting the difference treshold lower in each iteration, until there are sufficient enough points in the mask
        mask(mask<tresh) = 0; % getting the most significant differences, which have greater value than the treshold
        mask(mask~=0) = 1; % binary mask created, filled with 1s and 0s
    end
    
    %% Creating A Red Mask and Blending on Top of the Second Image
    %I wanted the mask to be red for better visualization
    redMask = cat(3, mask*255, zeros(size(mask)), zeros(size(mask))); %multiplying binary mask with 255 in the red domain of RGB, giving full red color in those locations
    
    img1RedLayerOnly = img1(:,:,1); img1GreenLayerOnly = img1(:,:,2); img1BlueLayerOnly = img1(:,:,3); %initializing layers
    img1RedLayerOnly(mask ~= 0) = 255; img1GreenLayerOnly(mask ~= 0) = 0; img1BlueLayerOnly(mask ~= 0) = 0; %initializing RGB masks according to the binary "mask", making nonzero locations red
    
    img2RedLayerOnly = img2(:,:,1); img2GreenLayerOnly = img2(:,:,2); img2BlueLayerOnly = img2(:,:,3);%initializing layers
    img2RedLayerOnly(mask ~= 0) = 255; img2GreenLayerOnly(mask ~= 0) = 0; img2BlueLayerOnly(mask ~= 0) = 0; %initializing RGB masks according to the binary "mask", making nonzero locations red
    
    img1WithRedMask = cat(3, img1RedLayerOnly, img1GreenLayerOnly, img1BlueLayerOnly); %"applying" mask on first image
    img2WithRedMask = cat(3, img2RedLayerOnly, img2GreenLayerOnly, img2BlueLayerOnly); %"applying" mask on second image
    
    %% Plotting Results
    figure;
    tiledlayout(2,2, 'Padding', 'none', 'TileSpacing', 'compact');
    
    nexttile
    imshow(img1); % First Image
    title("Image 1")
    
    nexttile
    imshow(img2); % Second Image
    title("Image 2")
    
    nexttile
    imshow(redMask); % Differences (Red Mask)
    title("Differences")
    
    nexttile
    imshow(img1WithRedMask); % Differences (Red Mask) Overlay on the First Image
    title("Image 1 with Differences Overlay")
    
    
    
